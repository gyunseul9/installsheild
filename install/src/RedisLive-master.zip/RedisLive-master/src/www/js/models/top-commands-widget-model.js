var TopCommandsWidgetModel = Backbone.Model.extend({
  
  url : "api/topcommands",

  initialize : function(){

  }

})
