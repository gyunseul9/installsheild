var TopKeysWidgetModel = Backbone.Model.extend({
  
  url : "api/topkeys",

  initialize : function(){

  }

})
