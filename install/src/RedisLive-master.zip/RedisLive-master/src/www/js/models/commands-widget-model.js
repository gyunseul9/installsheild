var CommandsWidgetModel = Backbone.Model.extend({
  
  url : "api/commands",

  initialize : function(){

  }

})
