var InfoWidgetModel = Backbone.Model.extend({

    url: "api/info",

    initialize: function() {        
    },

    defaults: {
    	"databases" : {}
    }
     
})
