var MemoryWidgetModel = Backbone.Model.extend({
  
  url : "api/memory",

  initialize : function(){

  }

})
