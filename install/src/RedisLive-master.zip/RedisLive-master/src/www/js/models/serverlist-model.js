var ServerListModel = Backbone.Model.extend({
  
  url : "api/servers",

  initialize : function(){

  }

})
